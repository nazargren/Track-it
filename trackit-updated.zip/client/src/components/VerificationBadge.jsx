// UI for showing if a user is verified
export default function VerificationBadge() { return <div>Verified Badge</div>; }