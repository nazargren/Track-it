// Profile for blood tracker with hound info
export default function TrackerProfile() { return <div>Tracker Profile</div>; }